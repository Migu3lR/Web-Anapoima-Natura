<?php __('plugin_price_default'); ?>
<input type="hidden" name="{INDEX}_adults[{RAND}]" value="0" />
<input type="hidden" name="{INDEX}_children[{RAND}]" value="0" />