<!DOCTYPE html>
<html lang="en">
<head>
	<title>Book</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
	<a href="{PJ_INSTALL_URL}book.html">{PJ_INSTALL_URL}book.html</a>
</body>
</html>