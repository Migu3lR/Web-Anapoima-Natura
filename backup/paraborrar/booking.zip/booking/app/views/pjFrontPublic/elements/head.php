<div class="panel-heading stivaPanelHead">
	<div class="row">
		<div class="col-md-1 col-sm-1 col-xs-2">
			<a href="#" class="btn btn-default stivaBtnHome hbSelectorSearch">
				<i class="fa fa-hotel"></i>
			</a>
		</div><!-- /.col- -->
		<div class="col-md-8 col-sm-8 col-xs-10">
		<?php include PJ_VIEWS_PATH . 'pjFront/elements/steps.php'; ?>
		</div><!-- /.col- -->
		<div class="col-md-3 col-sm-3 col-xs-12">
		<?php include PJ_VIEWS_PATH . 'pjFront/elements/locale.php'; ?>
		</div><!-- /.col- -->
	</div><!-- /.row -->
</div><!-- /.panel-heading stivaPanelHead -->