<?php
require $content_tpl;
?>