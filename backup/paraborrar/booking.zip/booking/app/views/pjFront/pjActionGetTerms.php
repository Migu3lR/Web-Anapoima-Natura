<div class="modal-header">
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
	<h4 class="modal-title"><?php __('front_terms'); ?></h4>
</div>
<div class="modal-body"><div class="te"><?php echo stripslashes($tpl['calendar_arr']['terms_body']); ?></div></div>
<div class="modal-footer">
	<button type="button" class="btn btn-default" data-dismiss="modal"><?php __('front_btn_close'); ?></button>
</div>